# Sistema de Atendimento Inteligente (Vue + Node)

Aplicação full‑stack para clínicas de pequeno porte com autenticação JWT, agendamento de consultas, preenchimento automático de endereço via CEP e alerta de chuva usando OpenWeather.

## Principais recursos
- Cadastro/login seguro para pacientes e secretários (JWT + bcrypt).
- Agendamento com checagem de horário disponível.
- Autocompletar endereço (ViaCEP).
- Alerta se há previsão de chuva no dia da consulta (OpenWeather 5‑day forecast).
- Painel administrativo com atualização de status (agendado, concluído, cancelado).

## Arquitetura
- **Backend**: Node.js + Express + MongoDB (mongoose), camadas de rotas/controllers/services, rate limit, Helmet e CORS configurável.
- **Frontend**: Vue 3 + Vite + Vue Router + Axios; guarda de rotas e sessão em `localStorage`.
- **Integrações**: ViaCEP (sem chave), OpenWeather (chave em `WEATHER_API_KEY`).

## Pré-requisitos
- Node 18+ e npm instalados.
- MongoDB em execução (local ou Atlas).

## Como rodar em desenvolvimento
Em dois terminais na raiz do projeto:

1) Backend
```bash
cd backend
cp .env.example .env   # preencha MONGO_URI, JWT_SECRET, WEATHER_API_KEY
npm install
npm run dev            # inicia em http://localhost:4000
```

2) Frontend
```bash
cd frontend
npm install
npm run dev            # inicia em http://localhost:5173
```

O Vite já proxia `/api` para `http://localhost:4000`.

### Dados de demonstração (seed)
Depois de configurar o `.env` e iniciar o Mongo, você pode popular usuários e um agendamento de exemplo:
```bash
cd backend
npm run seed
```
Cria:
- Secretária: `secretaria@clinica.com` / `senha123`
- Paciente: `paciente@clinica.com` / `senha123`
- Um agendamento para amanhã às 09:00.

## Variáveis de ambiente do backend (`backend/.env`)
- `PORT`: porta da API (default 4000).
- `MONGO_URI`: string de conexão do MongoDB.
- `JWT_SECRET`: chave segura para assinar tokens.
- `WEATHER_API_KEY`: chave do OpenWeather.
- `WEATHER_DEFAULT_CITY`: fallback para previsão (ex.: `Sao Paulo,BR`).
- `CLIENT_ORIGIN`: origens permitidas separadas por vírgula (ex.: `http://localhost:5173`).

## Endpoints principais
- `POST /api/auth/register` – cria usuário `{name,email,password,role}`.
- `POST /api/auth/login` – retorna `{user, token}`.
- `GET /api/auth/me` – perfil autenticado.
- `GET /api/appointments` – lista (secretário vê todos; paciente vê os próprios).
- `POST /api/appointments` – cria consulta `{dateTime, reason, cep?, number?, complement?}` com checagem de horário, ViaCEP e clima.
- `PUT /api/appointments/:id/status` – atualiza status (`scheduled|completed|cancelled`).
- `GET /api/appointments/availability?dateTime=...` – verifica conflito.
- `GET /api/cep/:cep` – retorna endereço ViaCEP.

## Fluxo sugerido no painel
1. Registrar usuário (paciente ou secretário) e fazer login.  
2. Na tela **Painel**, preencher data/hora e CEP; endereço preenche automático.  
3. Ao salvar, o backend marca se há chuva prevista no dia e salva o alerta no registro.  
4. Secretários podem concluir ou cancelar qualquer consulta; pacientes podem cancelar as próprias.

## Deploy rápido (sugestão)
- **Backend**: Render, Railway ou Fly.io (definir vars e apontar `npm start`).  
- **Frontend**: Netlify ou Vercel (`npm run build`, diretório `dist`, variável `VITE_API_URL` apontando para a API pública).  
- Banco: MongoDB Atlas (pegar a `MONGO_URI` e colocar no backend).

## Estrutura de pastas
```
backend/
  src/config      # env e conexão Mongo
  src/controllers # regras de negócio
  src/routes      # rotas Express
  src/services    # integrações (CEP, clima)
  src/middleware  # auth, validação
frontend/
  src/views       # telas Login, Registro, Dashboard
  src/components  # formulário e lista de consultas
  src/api         # clientes axios e sessão
```

## Próximos passos opcionais
- Adicionar testes (Jest/Supertest para API, Vitest/Testing Library no front).
- Fila para notificações (e-mail/SMS) no dia anterior.
- Papéis adicionais (médico) e bloqueio de slots por profissional.
